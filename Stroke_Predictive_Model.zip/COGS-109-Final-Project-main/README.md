# COGS-109-Final-Project

This is the repository for our group's COGS 109 Final Project

The project involves predicting wether or not someone will have a stroke based on physiological measures such as hypertension, heart disease, blood glucose level, 
and other factors, such as age.
